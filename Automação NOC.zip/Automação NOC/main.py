import customtkinter as ctk
import pyperclip, openpyxl, time, os, keyboard, ctypes, configparser, cv2, mss, threading
import numpy as np
import pyautogui
from datetime import datetime
from copy import copy

# Ajuste de DPI para precisão de clique no Windows
try:
    ctypes.windll.user32.SetProcessDPIAware()
except:
    pass

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

class CentralTecnocomp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("NOC Master - Tecnocomp | Sem Parar")
        self.geometry("600x850")
        self.attributes("-topmost", True)
        
        # Gerenciamento de caminhos e pastas
        self.diretorio = os.path.dirname(os.path.abspath(__file__))
        self.pasta_assets = os.path.join(self.diretorio, "assets")
        os.chdir(self.diretorio)

        # Garantir que a pasta assets existe para não dar erro
        if not os.path.exists(self.pasta_assets):
            os.makedirs(self.pasta_assets)
        
        self.ultimo_registro = None
        self.genesys_ativo = False
        
        # Carregamento de Configurações
        self.config, self.nome_analista = self.carregar_config()
        self.opcoes_crit = [i.strip() for i in self.config.get('OPCOES', 'criticidade').split(',')]
        self.opcoes_orig = [i.strip() for i in self.config.get('OPCOES', 'origem').split(',')]
        self.caminho_excel = os.path.join(self.diretorio, self.config.get('GERAL', 'arquivo_excel'))
        
        self.setup_ui()
        self.registrar_atalhos()

    def carregar_config(self):
        config = configparser.ConfigParser()
        path_config = os.path.join(self.diretorio, 'config.ini')
        
        if not os.path.exists(path_config):
            config.read_dict({
                'GERAL': {'nome_analista': 'Seu Nome Aqui', 'arquivo_excel': 'NOC - BASE BI 2024.xlsx'},
                'OPCOES': {'criticidade': 'High, Critical, Disaster, Warning', 'origem': 'Zabbix, New Relic, Dynatrace, ZENA, Grafana'}
            })
            with open(path_config, 'w', encoding='utf-8') as f: config.write(f)
        else:
            config.read(path_config, encoding='utf-8')
        return config, config.get('GERAL', 'nome_analista')

    def setup_ui(self):
        # Frame de Atalhos (Legenda)
        self.frame_atalhos = ctk.CTkFrame(self, fg_color="#1a1a1a")
        self.frame_atalhos.pack(pady=10, padx=20, fill="x")
        
        legenda = (
            "⌨️ ATALHOS:\n"
            "F9: Novo Alerta | F10: Repetir (Equipe/Crit/Orig)\n"
            "CTRL+S: Salvar no Excel | ESC: Desligar Chamada\n"
            "DEL: Cancelar Captura | END: Fechar Script"
        )
        self.lbl_atalhos = ctk.CTkLabel(self.frame_atalhos, text=legenda, font=("Consolas", 11), justify="left")
        self.lbl_atalhos.pack(pady=10, padx=10)

        # Monitor Genesys
        self.frame_g = ctk.CTkFrame(self, fg_color="#2b2b2b")
        self.frame_g.pack(pady=5, padx=20, fill="x")
        self.lbl_g = ctk.CTkLabel(self.frame_g, text="GENESYS: INATIVO", text_color="orange", font=("Roboto", 12, "bold"))
        self.lbl_g.pack(side="left", padx=20, pady=10)
        self.btn_g = ctk.CTkButton(self.frame_g, text="LIGAR MONITOR", width=120, command=self.toggle_genesys)
        self.btn_g.pack(side="right", padx=10)

        # Campos de Entrada
        self.frame_main = ctk.CTkFrame(self)
        self.frame_main.pack(pady=10, padx=20, fill="both")

        self.entries = {}
        campos = [("incidente", "Nº Incidente"), ("app", "Aplicação / Serviço"), 
                  ("horario", "Horário do Alerta"), ("equipe", "Equipe Responsável"),
                  ("analista_ac", "Analista AC")]
        
        for id_nome, label_texto in campos:
            ctk.CTkLabel(self.frame_main, text=label_texto).pack(pady=(2,0))
            ent = ctk.CTkEntry(self.frame_main, width=450)
            ent.pack(pady=(0,8))
            self.entries[id_nome] = ent

        ctk.CTkLabel(self.frame_main, text="Criticidade").pack(pady=(2,0))
        self.combo_crit = ctk.CTkOptionMenu(self.frame_main, values=self.opcoes_crit, width=450)
        self.combo_crit.pack(pady=(0,8))

        ctk.CTkLabel(self.frame_main, text="Origem").pack(pady=(2,0))
        self.combo_orig = ctk.CTkOptionMenu(self.frame_main, values=self.opcoes_orig, width=450)
        self.combo_orig.pack(pady=(0,8))
        
        self.txt_log = ctk.CTkTextbox(self, height=100, width=500, font=("Consolas", 11))
        self.txt_log.pack(pady=10)
        
        self.btn_save = ctk.CTkButton(self, text="SALVAR NO EXCEL (CTRL + S)", font=("Roboto", 14, "bold"), 
                                      fg_color="#28a745", command=self.salvar_alerta_ctrl_s)
        self.btn_save.pack(pady=5)

    def log(self, msg):
        self.txt_log.insert("end", f"> {msg}\n")
        self.txt_log.see("end")

    def localizar_e_clicar(self, img_name, acao_nome):
        posicao_original = pyautogui.position()
        caminho_img = os.path.join(self.pasta_assets, img_name)
        
        if not os.path.exists(caminho_img):
            self.log(f"⚠️ Erro: Imagem {img_name} não encontrada em /assets")
            return False

        with mss.mss() as sct:
            needle = cv2.imread(caminho_img)
            img = np.array(sct.grab({"top": 0, "left": 0, "width": 1920, "height": 1080}))
            img = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)
            res = cv2.matchTemplate(img, needle, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, max_loc = cv2.minMaxLoc(res)
            
            if max_val >= 0.75:
                h, w = needle.shape[:2]
                ponto = (max_loc[0] + w//2, max_loc[1] + h//2)
                pyautogui.moveTo(ponto[0], ponto[1], duration=0.2)
                pyautogui.click()
                self.log(f"✅ {acao_nome} executado.")
                pyautogui.moveTo(posicao_original[0], posicao_original[1], duration=0.1)
                return True
        return False

    def toggle_genesys(self):
        self.genesys_ativo = not self.genesys_ativo
        if self.genesys_ativo:
            self.lbl_g.configure(text="GENESYS: MONITORANDO", text_color="green")
            self.btn_g.configure(text="PARAR", fg_color="red")
            threading.Thread(target=self.loop_monitoramento, daemon=True).start()
        else:
            self.lbl_g.configure(text="GENESYS: INATIVO", text_color="orange")
            self.btn_g.configure(text="LIGAR", fg_color="#1f538d")

    def loop_monitoramento(self):
        while self.genesys_ativo:
            if self.localizar_e_clicar('botao_responder.png', "Atender"):
                time.sleep(1.5)
                for _ in range(8):
                    if self.localizar_e_clicar('icone_teclado.png', "Teclado"):
                        time.sleep(0.5)
                        pyautogui.press('1')
                        break
                    time.sleep(0.5)
            time.sleep(1)

    def ciclo_captura(self, repetir):
        for k, e in self.entries.items(): e.delete(0, "end")
        campos_fluxo = ["incidente", "app", "horario"]
        if not repetir: campos_fluxo += ["equipe", "analista_ac"]

        for campo in campos_fluxo:
            pyperclip.copy("")
            self.log(f"COPIE: {campo.upper()}")
            while pyperclip.paste() == "":
                if keyboard.is_pressed('del'): 
                    self.log("❌ Captura cancelada.")
                    return
                time.sleep(0.1)
            self.entries[campo].insert(0, pyperclip.paste().strip())
            time.sleep(0.2)

        if repetir and self.ultimo_registro:
            self.entries["equipe"].insert(0, self.ultimo_registro["equipe"])
            self.entries["analista_ac"].insert(0, self.ultimo_registro["analista_ac"])
            self.combo_crit.set(self.ultimo_registro["criticidade"])
            self.combo_orig.set(self.ultimo_registro["origem"])
        self.log("📝 Dados capturados. Verifique e salve.")

    def salvar_alerta_ctrl_s(self):
        try:
            if not os.path.exists(self.caminho_excel):
                self.log("❌ Erro: Planilha não encontrada!")
                return

            wb = openpyxl.load_workbook(self.caminho_excel)
            ws = wb.active
            linha_nova = 2
            while ws.cell(row=linha_nova, column=1).value: linha_nova += 1
            linha_anterior = linha_nova - 1 if linha_nova > 2 else 2

            dados = {k: v.get() for k, v in self.entries.items()}
            dados["criticidade"] = self.combo_crit.get()
            dados["origem"] = self.combo_orig.get()
            dados["data_auto"] = datetime.now().strftime("%d/%m/%Y")
            
            mapeamento = {
                "A": dados["incidente"], "B": dados["app"], "C": dados["data_auto"],
                "D": dados["horario"], "E": dados["equipe"], "F": dados["analista_ac"],
                "G": dados["criticidade"], "H": dados["origem"], "J": "Não",
                "L": self.nome_analista
            }
            
            for col, val in mapeamento.items():
                cell_nova = ws[f"{col}{linha_nova}"]
                cell_antiga = ws[f"{col}{linha_anterior}"]
                cell_nova.value = val
                if cell_antiga.has_style:
                    cell_nova.font = copy(cell_antiga.font)
                    cell_nova.border = copy(cell_antiga.border)
                    cell_nova.fill = copy(cell_antiga.fill)
                    cell_nova.number_format = copy(cell_antiga.number_format)
                    cell_nova.alignment = copy(cell_antiga.alignment)

            wb.save(self.caminho_excel)
            self.ultimo_registro = dados
            self.log(f"✅ SALVO LINHA {linha_nova}")
        except Exception as e: self.log(f"❌ Erro ao salvar: {e}")

    def registrar_atalhos(self):
        keyboard.add_hotkey('f9', lambda: threading.Thread(target=self.ciclo_captura, args=(False,)).start())
        keyboard.add_hotkey('f10', lambda: threading.Thread(target=self.ciclo_captura, args=(True,)).start())
        keyboard.add_hotkey('ctrl+s', self.salvar_alerta_ctrl_s)
        keyboard.add_hotkey('esc', lambda: threading.Thread(target=self.localizar_e_clicar, args=('botao_desligar.png', "Desligar")).start())
        keyboard.add_hotkey('end', os._exit, args=(0,))

if __name__ == "__main__":
    app = CentralTecnocomp()
    app.mainloop()